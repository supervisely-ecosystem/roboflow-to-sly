# car-wheels-001 > 2023-10-27 12:33pm
https://universe.roboflow.com/workspace001-bndzi/car-wheels-001

Provided by a Roboflow user
License: CC BY 4.0

